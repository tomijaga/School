#include "stdio.h"
#include "stdlib.h"
#include "string.h"

int myStrCmp(char *str1, char *str2);
int cmpEachChar(char *str1, char *str2, int i, int terminate);
