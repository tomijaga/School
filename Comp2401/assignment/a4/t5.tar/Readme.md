# Assignment 2

**Tomi Jaga, 101121458**

<br>

### Source Files

- makefile
- gridMain.c
- display.h
- display.c

<br>

### Compilation Instructions

- compile floorplan file

  > `make`

- run the floorplan executable:

> `./gridTester`
