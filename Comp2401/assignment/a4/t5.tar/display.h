#define  ENV_WIDTH       740
#define  ENV_HEIGHT      540


// These are the external functions being used by the test program
extern void initializeWindow() ;
extern void closeWindow();
extern void displayEnvironment(Environment *);
