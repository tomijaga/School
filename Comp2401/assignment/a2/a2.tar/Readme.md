# Assignment 2

**Tomi Jaga, 101121458**

<br>

### Source Files

- signCoder.c
- display.h
- display.c

<br>

### Compilation Instructions

- compile floorplan file

  > `gcc -o signCoder signCoder.c display.c -lX11`

- run the floorplan executable:

  > `./signCoder `
